#include "stm32f10x.h"
#include "linefollowing.h"
#include "motor.h"
#include "No_Mcu_Ganv_Grayscale_Sensor_Config.h"
#include "adc.h"
extern No_MCU_Sensor sensor;
extern volatile uint8_t g_finish_detected;
// PID����
float Kp = 15.0;
float Kd = 2.0;

float last_error = 0;
void line_following_task(void)
{

    unsigned short Anolog[8];
    unsigned char Digtal;
    //��ȡ�Ҷ�
    No_Mcu_Ganv_Sensor_Task_Without_tick(&sensor);
    Digtal = Get_Digtal_For_User(&sensor);
    Get_Anolog_Value(&sensor, Anolog);
    static uint8_t finish_counter = 0;
    int black_count = 0;
    for(int i=0;i<8;i++)
    {
        if(((Digtal>>i)&0x01)==0)
        {
            black_count++;
        }
    }

    // 6�����ϼ�������Ϊ�յ�
    if(black_count >= 6)
    {
        finish_counter++;
        if(finish_counter >= 3)
        {
            motor_stop();
            g_finish_detected = 1;
            return;
        }

    }
    else
    {
        finish_counter = 0;
    }
    if(g_finish_detected)
    {
        motor_stop();
        return;
    }

    /***************PIDѭ��****************/
    float error = 0;
    int count = 0;
    for(int i=0;i<8;i++)
    {
        //����
        if(((Digtal>>i)&0x01)==0)
        {
            error += (i - 3.5);
            count++;
        }
    }
    //������⵽��
    if(count > 0)
    {
        error = error / count;
    }
    else
    {
        //���߱��ַ���
        error = last_error;
    }
    //PID����
    float output;
    output = Kp * error + 
             Kd * (error-last_error);
    last_error = error;
    //����PID���
    if(output > 50)
        output = 50;
    if(output < -50)
        output = -50;
    /***************�ٶȼ���****************/
    int16_t base_speed = 15
	;
    int16_t left_speed;
    int16_t right_speed;
    /*
    error <0:
    ���������
    error >0:
    �������ұ�
    */
    left_speed  = base_speed + output;
    right_speed = base_speed - output;
    //�ٶ�����
    if(left_speed > 60)
        left_speed = 60;
    if(left_speed < 0)
        left_speed = 0;
    if(right_speed > 60)
        right_speed = 60;
    if(right_speed < 0)
        right_speed = 0;
    motor_forward(left_speed,right_speed);

}