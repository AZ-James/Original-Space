#include "button.h"
#include "delay.h"
#include "stm32f10x.h"


#define KEY1 GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_5)
#define KEY2 GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_12)


void Button_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;


    RCC_APB2PeriphClockCmd(
        RCC_APB2Periph_GPIOA,
        ENABLE
    );


    GPIO_InitStructure.GPIO_Pin =
        GPIO_Pin_5| GPIO_Pin_12;


    GPIO_InitStructure.GPIO_Mode =
        GPIO_Mode_IPD;


    GPIO_InitStructure.GPIO_Speed =
        GPIO_Speed_50MHz;


    GPIO_Init(
        GPIOA,
        &GPIO_InitStructure
    );

}



uint8_t Button1_Pressed(void)
{
    static uint8_t last_state = 0;


    uint8_t current;


    current = KEY1;



    // 0->1 ������
    if(last_state == 0 && current == 1)
    {

        Delay_ms(20);


        if(KEY1 == 1)
        {
            last_state = 1;
            return 1;
        }

    }


    if(current == 0)
    {
        last_state = 0;
    }


    return 0;
}

uint8_t Button2_Pressed(void)
{
    static uint8_t last_state = 0;


    uint8_t current;


    current = KEY2;



    // 0->1 ������
    if(last_state == 0 && current == 1)
    {

        Delay_ms(20);


        if(KEY2 == 1)
        {
            last_state = 1;
            return 1;
        }

    }


    if(current == 0)
    {
        last_state = 0;
    }


    return 0;
}