#include "stm32f10x.h"
#include "Encoder.h"



/*
    ����

    13�߻���
    ���ٱ�20

    13*20*4

*/

#define ENCODER_PER_ROUND 1040.0f



#define WHEEL_DIAMETER 48.0f



#define PI 3.1415926f

static int32_t Left_Total = 0;

static int32_t Right_Total = 0;





void Encoder_Init(void)
{

    GPIO_InitTypeDef GPIO_InitStructure;

    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;

    TIM_ICInitTypeDef TIM_ICInitStructure;



    /*
        ��GPIOA
    */

    RCC_APB2PeriphClockCmd(
        RCC_APB2Periph_GPIOA,
        ENABLE
    );



    /*
        ��TIM2 TIM3

    */

    RCC_APB1PeriphClockCmd(
        RCC_APB1Periph_TIM2 |
        RCC_APB1Periph_TIM3,
        ENABLE
    );



    /*
        PA0 PA1

        ���ֱ�����
    */


    GPIO_InitStructure.GPIO_Pin =
        GPIO_Pin_0 |
        GPIO_Pin_1;



    GPIO_InitStructure.GPIO_Mode =
        GPIO_Mode_IN_FLOATING;



    GPIO_InitStructure.GPIO_Speed =
        GPIO_Speed_50MHz;



    GPIO_Init(
        GPIOA,
        &GPIO_InitStructure
    );



    /*
        PA6 PA7

        ���ֱ�����
    */


    GPIO_InitStructure.GPIO_Pin =
        GPIO_Pin_6 |
        GPIO_Pin_7;



    GPIO_Init(
        GPIOA,
        &GPIO_InitStructure
    );



    /*
        TIM2
    */


    TIM_TimeBaseStructInit(
        &TIM_TimeBaseStructure
    );


    TIM_TimeBaseStructure.TIM_Period =
        65535;


    TIM_TimeBaseStructure.TIM_Prescaler =
        0;



    TIM_TimeBaseInit(
        TIM2,
        &TIM_TimeBaseStructure
    );



    TIM_EncoderInterfaceConfig(
        TIM2,
        TIM_EncoderMode_TI12,
        TIM_ICPolarity_Rising,
        TIM_ICPolarity_Rising
    );



    TIM_ICStructInit(
        &TIM_ICInitStructure
    );


    TIM_ICInitStructure.TIM_ICFilter = 10;


    TIM_ICInit(
        TIM2,
        &TIM_ICInitStructure
    );



    TIM_SetCounter(
        TIM2,
        0
    );



    TIM_Cmd(
        TIM2,
        ENABLE
    );




    /*
        TIM3

        ����
    */


    TIM_TimeBaseInit(
        TIM3,
        &TIM_TimeBaseStructure
    );



    TIM_EncoderInterfaceConfig(
        TIM3,
        TIM_EncoderMode_TI12,
        TIM_ICPolarity_Rising,
        TIM_ICPolarity_Rising
    );



    TIM_ICInitStructure.TIM_ICFilter = 10;



    TIM_ICInit(
        TIM3,
        &TIM_ICInitStructure
    );



    TIM_SetCounter(
        TIM3,
        0
    );



    TIM_Cmd(
        TIM3,
        ENABLE
    );


}




/*
    ��ȡ�ٶ�

    ÿ����һ�Σ�

    ������һ����ת�����ٱ���ֵ

*/

int16_t Encoder_GetLeftSpeed(void)
{

    int16_t count;


    count =
    (int16_t)TIM_GetCounter(TIM3);


    TIM_SetCounter(
        TIM3,
        0
    );


    Left_Total += count;


    return count;

}





int16_t Encoder_GetRightSpeed(void)
{

    int16_t count;


    count =
    (int16_t)TIM_GetCounter(TIM2);



    TIM_SetCounter(
        TIM2,
        0
    );


    Right_Total += count;


    return count;

}






void Encoder_Reset(void)
{

    Left_Total = 0;

    Right_Total = 0;


    TIM_SetCounter(
        TIM2,
        0
    );


    TIM_SetCounter(
        TIM3,
        0
    );

}







int32_t Encoder_GetLeftTotal(void)
{

    return Left_Total;

}




int32_t Encoder_GetRightTotal(void)
{

    return Right_Total;

}







float Encoder_GetDistance(void)
{

    float count;


    /*
        ������ƽ��

    */

    count =
    (Left_Total + Right_Total) / 2.0f;



    /*
        countת������

    */

    return
    count *
    (PI * WHEEL_DIAMETER)
    /
    ENCODER_PER_ROUND;

}
