#ifndef __MOTOR_H
#define __MOTOR_H

#include "stm32f10x.h"

void Motor_Init(void);

void Motor_Set(int left,int right);

void Motor_Stop(void);

#endif
