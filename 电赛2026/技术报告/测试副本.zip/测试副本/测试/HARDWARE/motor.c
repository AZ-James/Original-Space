#include "stm32f10x.h"
#include "motor.h"
#include "pwm.h"


#define AIN1 GPIO_Pin_14
#define AIN2 GPIO_Pin_15
#define BIN1 GPIO_Pin_13
#define BIN2 GPIO_Pin_12
#define STBY GPIO_Pin_4



void Motor_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;


    RCC_APB2PeriphClockCmd(
        RCC_APB2Periph_GPIOA |
        RCC_APB2Periph_GPIOB,
        ENABLE
    );


    // Motor direction pins

    GPIO_InitStructure.GPIO_Pin =
        AIN1|
        AIN2|
        BIN1|
        BIN2;

    GPIO_InitStructure.GPIO_Mode =
        GPIO_Mode_Out_PP;

    GPIO_InitStructure.GPIO_Speed =
        GPIO_Speed_50MHz;


    GPIO_Init(
        GPIOB,
        &GPIO_InitStructure
    );



    // STBY pin PA4

    GPIO_InitStructure.GPIO_Pin =
        STBY;


    GPIO_Init( GPIOA,&GPIO_InitStructure);


    PWM_Init();


    Motor_Stop();
}



void Motor_Enable(void)
{
    GPIO_SetBits(
        GPIOA,
        STBY
    );
}



void Motor_Disable(void)
{
    GPIO_ResetBits(
        GPIOA,
        STBY
    );
}



void Motor_Set(int left,int right)
{

    // Enable TB6612 automatically

    Motor_Enable();


   



    // Left motor forward

    GPIO_SetBits(
        GPIOB,
        AIN1
    );

    GPIO_ResetBits(
        GPIOB,
        AIN2
    );


    PWM_SetCompareA(left);



    // Right motor forward

    GPIO_SetBits(
        GPIOB,
        BIN1
    );

    GPIO_ResetBits(
        GPIOB,
        BIN2
    );


    PWM_SetCompareB(right);

}

void Motor_Stop(void)
{

    PWM_SetCompareA(0);

    PWM_SetCompareB(0);


    GPIO_ResetBits(
        GPIOB,
        AIN1|
        AIN2|
        BIN1|
        BIN2
    );


    Motor_Disable();

}
