#include "stm32f10x.h"

#include "Timer.h"
#include "Trace.h"
#include "motor.h"
#include "MPU6050.h"


#define STOP_ANGLE    (-310.0f)


volatile uint16_t Run_Time_ms = 0;


/* 100ms计时分频 */
static uint8_t Timer_Count = 0;



void Timer_Init(void)
{
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    NVIC_InitTypeDef NVIC_InitStructure;


    RCC_APB1PeriphClockCmd(
        RCC_APB1Periph_TIM4,
        ENABLE
    );


    TIM_TimeBaseStructure.TIM_Prescaler =
        7200 - 1;

    TIM_TimeBaseStructure.TIM_Period =
        100 - 1;

    TIM_TimeBaseStructure.TIM_CounterMode =
        TIM_CounterMode_Up;

    TIM_TimeBaseStructure.TIM_ClockDivision =
        TIM_CKD_DIV1;


    TIM_TimeBaseInit(
        TIM4,
        &TIM_TimeBaseStructure
    );


    TIM_ClearITPendingBit(
        TIM4,
        TIM_IT_Update
    );


    TIM_ITConfig(
        TIM4,
        TIM_IT_Update,
        ENABLE
    );


    NVIC_InitStructure.NVIC_IRQChannel =
        TIM4_IRQn;

    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority =
        1;

    NVIC_InitStructure.NVIC_IRQChannelSubPriority =
        1;

    NVIC_InitStructure.NVIC_IRQChannelCmd =
        ENABLE;


    NVIC_Init(
        &NVIC_InitStructure
    );


    /* 初始化后不启动 */
    TIM_Cmd(
        TIM4,
        DISABLE
    );
}



void Trace_Timer_Start(void)
{
    /* 计时归零 */
    Run_Time_ms = 0;

    Timer_Count = 0;


    /* 定时器从0重新开始 */
    TIM_SetCounter(
        TIM4,
        0
    );


    TIM_ClearITPendingBit(
        TIM4,
        TIM_IT_Update
    );


    TIM_Cmd(
        TIM4,
        ENABLE
    );
}



void Trace_Timer_Stop(void)
{
    TIM_Cmd(
        TIM4,
        DISABLE
    );
}



void TIM4_IRQHandler(void)
{
    float Angle;

    if(TIM_GetITStatus(TIM4, TIM_IT_Update) == SET)
    {
        /*
         * 这里只积分
         * 不读I2C
         */
        MPU6050_UpdateAngle();


        Angle =
            MPU6050_GetAngle();


        /*
         * 顺时针为负
         *
         * 累计达到目标角度
         * 直接停车
         */
        if(Angle <= STOP_ANGLE)
        {
            Motor_Stop();

            Trace_Timer_Stop();


            TIM_ClearITPendingBit(
                TIM4,
                TIM_IT_Update
            );

            return;
        }


        /* 正常循迹 */
        Trace_Task();


        Timer_Count++;

        if(Timer_Count >= 10)
        {
            Timer_Count = 0;

            Run_Time_ms++;
        }


        TIM_ClearITPendingBit(
            TIM4,
            TIM_IT_Update
        );
    }
}
