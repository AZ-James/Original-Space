#ifndef __PWM_H
#define __PWM_H

#include "stm32f10x.h"

void PWM_Init(void);

void PWM_SetCompareA(uint16_t Compare);

void PWM_SetCompareB(uint16_t Compare);

#endif
