#include "stm32f10x.h"
#include "delay.h"


// SysTick???
void Delay_Init(void)
{
    // SysTick?? = HCLK = 72MHz

    SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK);
}



// ????
void Delay_us(uint32_t us)
{
    uint32_t temp;


    SysTick->LOAD = 72 * us;


    SysTick->VAL = 0x00;


    SysTick->CTRL =
        SysTick_CTRL_CLKSOURCE_Msk |
        SysTick_CTRL_ENABLE_Msk;


    do
    {
        temp = SysTick->CTRL;

    }while((temp & SysTick_CTRL_COUNTFLAG_Msk)==0);


    SysTick->CTRL = 0;

    SysTick->VAL = 0;
}



// ????
void Delay_ms(uint32_t ms)
{

    while(ms--)
    {
        Delay_us(1000);
    }

}
