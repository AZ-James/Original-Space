#include "stm32f10x.h"
#include "pwm.h"


void PWM_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    TIM_OCInitTypeDef TIM_OCInitStructure;


    RCC_APB2PeriphClockCmd(
        RCC_APB2Periph_GPIOA |
        RCC_APB2Periph_TIM1,
        ENABLE
    );


    // PA8 TIM1_CH1
    // PA11 TIM1_CH4

    GPIO_InitStructure.GPIO_Pin =
        GPIO_Pin_8 |
        GPIO_Pin_11;

    GPIO_InitStructure.GPIO_Mode =
        GPIO_Mode_AF_PP;

    GPIO_InitStructure.GPIO_Speed =
        GPIO_Speed_50MHz;


    GPIO_Init(
        GPIOA,
        &GPIO_InitStructure
    );



    /*
        TIM1时钟:
        72MHz

        PSC = 72-1

        计数频率:
        72MHz / 72 = 1MHz


        ARR = 100-1

        PWM频率:
        1MHz / 100 = 10kHz

    */


    TIM_TimeBaseStructure.TIM_Prescaler =
        72-1;


    TIM_TimeBaseStructure.TIM_Period =
        100-1;


    TIM_TimeBaseStructure.TIM_CounterMode =
        TIM_CounterMode_Up;


    TIM_TimeBaseStructure.TIM_ClockDivision =
        TIM_CKD_DIV1;



    TIM_TimeBaseInit(
        TIM1,
        &TIM_TimeBaseStructure
    );



    TIM_OCInitStructure.TIM_OCMode =
        TIM_OCMode_PWM1;


    TIM_OCInitStructure.TIM_OutputState =
        TIM_OutputState_Enable;


    // 初始占空比0

    TIM_OCInitStructure.TIM_Pulse =
        0;


    TIM_OCInitStructure.TIM_OCPolarity =
        TIM_OCPolarity_High;



    // PA8 CH1

    TIM_OC1Init(
        TIM1,
        &TIM_OCInitStructure
    );



    // PA11 CH4

    TIM_OC4Init(
        TIM1,
        &TIM_OCInitStructure
    );



    TIM_OC1PreloadConfig(
        TIM1,
        TIM_OCPreload_Enable
    );


    TIM_OC4PreloadConfig(
        TIM1,
        TIM_OCPreload_Enable
    );



    // TIM1高级定时器必须开启

    TIM_CtrlPWMOutputs(
        TIM1,
        ENABLE
    );


    TIM_Cmd(
        TIM1,
        ENABLE
    );

}



void PWM_SetCompareA(uint16_t Compare)
{
    TIM_SetCompare4(
        TIM1,
        Compare
    );
}



void PWM_SetCompareB(uint16_t Compare)
{
    TIM_SetCompare1(
        TIM1,
        Compare
    );
}
