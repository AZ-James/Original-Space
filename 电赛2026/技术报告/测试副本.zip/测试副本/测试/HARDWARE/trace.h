#ifndef __TRACE_H
#define __TRACE_H

#include "stm32f10x.h"

void Trace_Init(void);

void Trace_Task(void);


uint8_t Trace_GetX1(void);
uint8_t Trace_GetX2(void);
uint8_t Trace_GetX3(void);
uint8_t Trace_GetX4(void);
#endif
