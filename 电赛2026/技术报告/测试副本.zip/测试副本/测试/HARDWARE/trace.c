#include "stm32f10x.h"
#include "Trace.h"
#include "motor.h"


#define X1 GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_0)
#define X2 GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_1)

#define X3 GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_9)
#define X4 GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_10)



extern uint8_t Trace_Mode;


int BASE_SPEED;

int KP;

int KD;


void Trace_Init(void)
{

    GPIO_InitTypeDef GPIO_InitStructure;


    RCC_APB2PeriphClockCmd(
        RCC_APB2Periph_GPIOA |
        RCC_APB2Periph_GPIOB,
        ENABLE
    );


    // PA9 PA10

    GPIO_InitStructure.GPIO_Pin =
        GPIO_Pin_9 |
        GPIO_Pin_10;


    GPIO_InitStructure.GPIO_Mode =
        GPIO_Mode_IPU;


    GPIO_InitStructure.GPIO_Speed =
        GPIO_Speed_50MHz;


    GPIO_Init(
        GPIOA,
        &GPIO_InitStructure
    );



    // PB0 PB1

    GPIO_InitStructure.GPIO_Pin =
        GPIO_Pin_0 |
        GPIO_Pin_1;


    GPIO_Init(
        GPIOB,
        &GPIO_InitStructure
    );

}



void Trace_Task(void)
{

    if(Trace_Mode==0)
    {

        BASE_SPEED=30;

        KP=6;

        KD=12;

    }


    else
    {

        BASE_SPEED=15;

        KP=3;

        KD=10;

    }
	static int last_error=0;


    int error=0;

    int derivative;

    int correction;


    int left;

    int right;



    //左外

    if(X3==0)
        error-=3;


    //左内

    if(X4==0)
        error-=1;


    //右内

    if(X2==0)
        error+=1;


    //右外

    if(X1==0)
        error+=3;



    derivative =
        error-last_error;


    correction =
        KP*error+
        KD*derivative;


    last_error=error;



    left =
        BASE_SPEED+
        correction;


    right =
        BASE_SPEED-
        correction;



    if(left>100)
        left=100;


    if(right>100)
        right=100;


    if(left<0)
        left=0;


    if(right<0)
        right=0;



    Motor_Set(
        left,
        right
    );

}


void Trace_SetMode(uint8_t mode)
{

    Trace_Mode=mode;

}
uint8_t Trace_GetX1(void)
{
    return X1;
}


uint8_t Trace_GetX2(void)
{
    return X2;
}


uint8_t Trace_GetX3(void)
{
    return X3;
}


uint8_t Trace_GetX4(void)
{
    return X4;
}
