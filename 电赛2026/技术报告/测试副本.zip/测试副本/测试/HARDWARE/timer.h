#ifndef __TIMER_H
#define __TIMER_H

#include "stm32f10x.h"


extern volatile uint16_t Run_Time_ms;


void Timer_Init(void);

void Trace_Timer_Start(void);

void Trace_Timer_Stop(void);


#endif
