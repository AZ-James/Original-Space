#include "stm32f10x.h"

#include "motor.h"
#include "Trace.h"
#include "button.h"
#include "Timer.h"
#include "OLED.h"
#include "MPU6050.h"
#include "delay.h"

uint8_t Trace_Mode = 0;
int main(void)
{
    float Angle;


    Motor_Init();

    Trace_Init();

    Button_Init();

    Timer_Init();

    OLED_Init();

    MPU6050_Init();


    Motor_Stop();


    /* ==================== MPU�ȶ� ==================== */


    Delay_ms(2000);


    /* ==================== ��ֹУ׼ ==================== */

    OLED_ShowString(
        1,
        1,
        "CAL "
    );

    MPU6050_Calibrate();

    MPU6050_ResetAngle();


    OLED_Clear();

    OLED_ShowString(
        1,
        1,
        "T:"
    );

    OLED_ShowString(
        2,
        1,
        "A:"
    );

    OLED_ShowString(
        3,
        1,
        "O:"
    );


    /* ��ʾУ׼��ƫ */
    OLED_ShowSignedNum(
        3,
        3,
        (int32_t)MPU6050_GetGyroZOffset(),
        5
    );


    while(1)
    {
        /*
         * mainֻ���𲻶ϻ�ȡ
         * ����GyroZ
         */
        MPU6050_PollGyroZ();


        /*
         * ����˲ʱ����һ��
         */
        if(Button1_Pressed())
        {
            /*
             * ����ǰ�Ƕ�����
             */
            Trace_Mode = 0;
			MPU6050_ResetAngle();


            /*
             * ����TIM4��
             * ѭ��
             * ����
             * ��ʱ
             */
            Trace_Timer_Start();
        }
       
        if(Button2_Pressed())
        {
            /*
             * ����ǰ�Ƕ�����
             */
            
			Trace_Mode = 1;
			
			MPU6050_ResetAngle();


            /*
             * ����TIM4��
             * ѭ��
             * ����
             * ��ʱ
             */
            Trace_Timer_Start();
        }

        /*
         * �����ۼƽǶ�
         * ����˲ʱGyroZ
         */
        Angle =
            MPU6050_GetAngle();


        /* ==================== ʱ�� ==================== */

        OLED_ShowNum(
            1,
            3,
            Run_Time_ms / 10,
            2
        );


        OLED_ShowChar(
            1,
            5,
            '.'
        );


        OLED_ShowNum(
            1,
            6,
            Run_Time_ms % 10,
            1
        );


        /* ==================== �ۼƽǶ� ==================== */

        OLED_ShowSignedNum(
            2,
            3,
            (int32_t)Angle,
            4
        );
    }
}
